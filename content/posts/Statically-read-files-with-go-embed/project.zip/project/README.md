# Statically read files with go-embed

This is the example repository for the [Statically read files with go-embed](www.vknabel.com/posts/statically-read-files-with-go-embed/) tutorial.
